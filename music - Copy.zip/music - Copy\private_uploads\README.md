# Private uploads

Simpan fail media local yang tidak boleh diakses terus melalui `public/`.

Gunakan API berikut:

- Video/audio stream: `/api/stream?file=video-13s.mp4`
- Gambar/private file: `/api/media/nama-file.jpg`

Jangan commit fail media sensitif ke Git.
