import { useState, useEffect } from 'react';
import { Play, Plus, Radio, Check, PlusSquare } from 'lucide-react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { usePlayerStore, Track } from '@/lib/store';
import { db } from '@/lib/db';
import { MarqueeText } from './MarqueeText';

interface PlaylistData {
  playlistId: string;
  name: string;
  thumbnails: { url: string; width: number; height: number }[];
  videos: Track[];
}

export function CommunityPlaylistCard({ playlistId }: { playlistId: string }) {
  const [playlist, setPlaylist] = useState<PlaylistData | null>(null);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);
  const router = useRouter();
  const playTrack = usePlayerStore((state) => state.playTrack);

  useEffect(() => {
    const fetchPlaylist = async () => {
      try {
        const res = await fetch(`/api/ytplaylist?id=${playlistId}`);
        if (res.ok) {
          const data = await res.json();
          setPlaylist({
            ...data,
            videos: data.videos || data.songs || []
          });
        }
      } catch (error) {
        console.error('Failed to fetch playlist:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPlaylist();
  }, [playlistId]);

  if (loading) {
    return (
      <div className="w-[320px] bg-[#1C1C1E] rounded-3xl p-5 shrink-0 snap-center flex flex-col animate-pulse">
        <div className="flex gap-4 mb-6">
          <div className="w-24 h-24 rounded-2xl bg-white/10 shrink-0" />
          <div className="flex flex-col justify-center flex-1">
            <div className="h-5 w-3/4 bg-white/10 rounded-md mb-2" />
            <div className="h-4 w-1/2 bg-white/10 rounded-md" />
          </div>
        </div>

        <div className="flex-1 space-y-4 mb-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-white/10 shrink-0" />
              <div className="flex flex-col flex-1 gap-2">
                <div className="h-4 w-full bg-white/10 rounded-md" />
                <div className="h-3 w-2/3 bg-white/10 rounded-md" />
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between mt-auto">
          <div className="flex gap-3">
            <div className="w-12 h-12 rounded-full bg-white/10" />
            <div className="w-12 h-12 rounded-full bg-white/10" />
          </div>
          <div className="w-12 h-12 rounded-full bg-white/10" />
        </div>
      </div>
    );
  }

  if (!playlist) {
    return null;
  }

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (playlist.videos && playlist.videos.length > 0) {
      playTrack(playlist.videos[0], playlist.videos, 'playlist');
    }
  };

  const handleAdd = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!added) {
      await db.addPlaylist({
        id: playlist.playlistId,
        name: playlist.name,
        img: playlist.thumbnails?.[playlist.thumbnails.length - 1]?.url || '',
        tracks: playlist.videos || []
      });
      setAdded(true);
    }
  };

  const handleRadio = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Start radio based on the first track
    if (playlist.videos && playlist.videos.length > 0) {
      playTrack(playlist.videos[0], [], 'similar');
    }
  };

  const handleClick = () => {
    router.push(`/playlist/${playlist.playlistId}`);
  };

  const displayTracks = playlist.videos?.slice(0, 3) || [];

  return (
    <div 
      onClick={handleClick}
      className="w-[320px] bg-[#1C1C1E] rounded-3xl p-5 shrink-0 snap-center cursor-pointer hover:bg-[#2C2C2E] transition-colors flex flex-col"
    >
      <div className="flex gap-4 mb-6">
        <div className="w-24 h-24 rounded-2xl overflow-hidden relative shrink-0 shadow-lg bg-black/20">
          {playlist.videos && playlist.videos.length >= 4 ? (
            <div className="grid grid-cols-2 grid-rows-2 w-full h-full">
              {playlist.videos.slice(0, 4).map((track, i) => (
                <div key={i} className="relative w-full h-full">
                  <Image 
                    src={track.thumbnails?.[track.thumbnails.length - 1]?.url || '/placeholder.png'} 
                    alt={track.name} 
                    fill 
                    sizes="48px" 
                    className="object-cover" 
                  />
                </div>
              ))}
            </div>
          ) : (
            <Image 
              src={playlist.thumbnails?.[playlist.thumbnails.length - 1]?.url || '/placeholder.png'} 
              alt={playlist.name} 
              fill 
              sizes="96px" 
              className="object-cover" 
            />
          )}
        </div>
        <div className="flex flex-col justify-center min-w-0 flex-1">
          <MarqueeText text={playlist.name} className="text-white font-bold text-lg leading-tight mb-1" />
          <p className="text-white/50 text-sm">{playlist.videos?.length || 0} lagu</p>
        </div>
      </div>

      <div className="flex-1 space-y-4 mb-6">
        {displayTracks.map((track, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg overflow-hidden relative shrink-0">
              <Image 
                src={track.thumbnails?.[track.thumbnails.length - 1]?.url || '/placeholder.png'} 
                alt={track.name} 
                fill 
                sizes="48px" 
                className="object-cover" 
              />
            </div>
            <div className="flex flex-col overflow-hidden min-w-0 flex-1">
              <MarqueeText text={track.name} className="text-white text-[15px] font-medium" />
              <MarqueeText 
                text={Array.isArray(track.artist) ? track.artist.map(a => a.name).join(', ') : track.artist?.name || 'Unknown Artist'} 
                className="text-white/50 text-sm" 
              />
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-3 mt-auto">
        <button 
          onClick={handlePlay}
          aria-label={`Putar ${playlist.name}`}
          className="w-14 h-14 rounded-full flex items-center justify-center border border-white/70 bg-white/35 backdrop-blur-xl shadow-[inset_0_1px_1px_rgba(255,255,255,0.9),0_8px_24px_rgba(255,255,255,0.16)] hover:bg-white/50 hover:scale-105 active:scale-95 transition-all"
        >
          <Play className="w-7 h-7 text-black fill-current ml-1" />
        </button>
        <button 
          onClick={handleRadio}
          className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
        >
          <Radio className="w-6 h-6 text-white" />
        </button>
        <button 
          onClick={handleAdd}
          className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
        >
          {added ? <Check className="w-6 h-6 text-white" /> : <PlusSquare className="w-6 h-6 text-white" />}
        </button>
      </div>
    </div>
  );
}
