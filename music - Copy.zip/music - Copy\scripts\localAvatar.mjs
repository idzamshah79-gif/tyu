import { readFileSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const directory = path.join(root, 'public', 'AvatarTiktok');
const manifestFile = path.join(directory, 'manifest.json');
const profilesFile = path.join(root, 'app', 'lib', 'tiktokProfiles.json');
const hosts = new Set(['tiktok.com', 'www.tiktok.com', 'm.tiktok.com']);
const usernamePattern = /^[A-Za-z0-9._-]{2,24}$/;

function loadEnvFile(filename) {
  try {
    const text = readFileSync(path.join(root, filename), 'utf8');
    for (const line of text.split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*["']?([^"']*)["']?\s*$/);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2];
    }
  } catch {}
}

function parseProfile(value) {
  try {
    const url = new URL(value);
    const username = url.pathname.match(/^\/@([A-Za-z0-9._-]{2,24})\/?$/)?.[1];
    if (url.protocol !== 'https:' || !hosts.has(url.hostname.toLowerCase()) || !usernamePattern.test(username || '')) return null;
    return { username, profileUrl: `https://www.tiktok.com/@${username}` };
  } catch {
    return null;
  }
}

async function readManifest() {
  try {
    const manifest = JSON.parse(await readFile(manifestFile, 'utf8'));
    return Array.isArray(manifest.profiles) ? manifest : { profiles: [] };
  } catch {
    return { profiles: [] };
  }
}

async function readProfiles() {
  try {
    const profiles = JSON.parse(await readFile(profilesFile, 'utf8'));
    return Array.isArray(profiles) ? profiles : [];
  } catch {
    return [];
  }
}

loadEnvFile('.env.local');
loadEnvFile('.env');
const input = process.argv[2];
const apiKey = process.env.SOCIA_VAULT_API_KEY;
if (!input) throw new Error('Usage: npm run local:avatar -- "https://www.tiktok.com/@username"');
if (!apiKey) throw new Error('SOCIA_VAULT_API_KEY tidak dijumpai dalam .env atau .env.local.');

const profile = parseProfile(input);
if (!profile) throw new Error('Link mesti berupa profil TikTok yang sah.');

const response = await fetch(`https://api.sociavault.com/v1/scrape/tiktok/profile?handle=${encodeURIComponent(profile.username)}`, {
  headers: { Accept: 'application/json', 'X-API-Key': apiKey },
});
if (!response.ok) throw new Error(`SociaVault API returned HTTP ${response.status}.`);
const payload = await response.json();
const user = payload?.data?.user;
const imageUrl = typeof user?.avatarLarger === 'string' ? user.avatarLarger : user?.avatarMedium;
if (typeof imageUrl !== 'string') throw new Error('Avatar tidak tersedia daripada SociaVault.');
if (!/^https:\/\/(?:[^/]+\.)?(?:tiktokcdn(?:-[a-z]+)?|ibytedtos|muscdn)\.[^/]+\//i.test(imageUrl)) throw new Error('URL avatar SociaVault bukan CDN TikTok yang dibenarkan.');

const image = await fetch(imageUrl);
if (!image.ok) throw new Error(`Avatar download returned HTTP ${image.status}.`);
const contentType = image.headers.get('content-type')?.split(';')[0].toLowerCase();
const extension = contentType === 'image/webp' ? 'webp' : contentType === 'image/png' ? 'png' : 'jpg';
const filename = `${profile.username}.${extension}`;
await mkdir(directory, { recursive: true });
await writeFile(path.join(directory, filename), Buffer.from(await image.arrayBuffer()));

const manifest = await readManifest();
const profiles = await readProfiles();
const existingManifest = manifest.profiles.find((saved) => saved.username.replace(/^@/, '') === profile.username);
const existingProfile = profiles.find((saved) => saved.username.replace(/^@/, '') === profile.username);
const savedName = typeof existingManifest?.name === 'string' && existingManifest.name.trim()
  ? existingManifest.name
  : typeof existingProfile?.name === 'string' && existingProfile.name.trim()
    ? existingProfile.name
    : typeof user?.nickname === 'string' && user.nickname.trim() ? user.nickname.trim() : profile.username;
const savedUsername = typeof user?.uniqueId === 'string' && usernamePattern.test(user.uniqueId) ? user.uniqueId : profile.username;
const item = {
  username: `@${savedUsername}`,
  profileUrl: profile.profileUrl,
  avatar: `/AvatarTiktok/${filename}`,
  name: savedName,
  isVerified: user?.verified === true,
  updatedAt: new Date().toISOString(),
};
const manifestItem = {
  username: savedUsername,
  profileUrl: profile.profileUrl,
  avatar: item.avatar,
  name: typeof existingManifest?.name === 'string' && existingManifest.name.trim() ? existingManifest.name : savedName,
  updatedAt: item.updatedAt,
};
const index = manifest.profiles.findIndex((saved) => saved.username === savedUsername);
if (index === -1) manifest.profiles.push(manifestItem);
else manifest.profiles[index] = manifestItem;
await writeFile(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`);

const profileIndex = profiles.findIndex((saved) => saved.username.replace(/^@/, '') === savedUsername);
const nextId = profiles.reduce((highest, saved) => Math.max(highest, Number(saved.id) || 0), 0) + 1;
const profileItem = { id: profileIndex === -1 ? nextId : profiles[profileIndex].id, name: savedName, username: item.username, url: profile.profileUrl, avatar: item.avatar, isVerified: item.isVerified };
if (profileIndex === -1) profiles.push(profileItem);
else profiles[profileIndex] = profileItem;
await writeFile(profilesFile, `${JSON.stringify(profiles, null, 2)}\n`);

console.log(JSON.stringify({ success: true, profile: profileItem, manifest: manifestItem }, null, 2));
