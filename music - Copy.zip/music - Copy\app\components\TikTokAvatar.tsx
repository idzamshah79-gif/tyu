'use client';

import Image from 'next/image';
import { Search, LoaderCircle } from 'lucide-react';
import { FormEvent, useState } from 'react';

type TikTokAvatarResult = {
  success: true;
  username: string;
  avatar: string;
  profileUrl: string;
};

export default function TikTokAvatar() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<TikTokAvatarResult | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  async function findAvatar(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError('');
    setResult(null);
    try {
      const response = await fetch('/api/tiktok/avatar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: input }),
      });
      const data = await response.json() as TikTokAvatarResult & { error?: string };
      if (!response.ok || !data.success) throw new Error(data.error || 'Avatar TikTok tidak tersedia.');
      setResult(data);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Avatar TikTok tidak tersedia.');
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <section className="w-full max-w-sm rounded-2xl border border-white/10 bg-white/[0.06] p-4 text-white shadow-xl backdrop-blur-xl">
      <form onSubmit={findAvatar} className="flex gap-2">
        <input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Username atau link TikTok" aria-label="Username atau link TikTok" className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-sm outline-none placeholder:text-white/40 focus:border-[#4ADE80]" />
        <button type="submit" disabled={isLoading || !input.trim()} aria-label="Cari avatar TikTok" className="rounded-xl bg-[#4ADE80] p-2 text-black transition-opacity hover:opacity-85 disabled:cursor-not-allowed disabled:opacity-50">
          {isLoading ? <LoaderCircle className="h-5 w-5 animate-spin" /> : <Search className="h-5 w-5" />}
        </button>
      </form>
      {error && <p role="alert" className="mt-3 text-sm text-red-300">{error}</p>}
      {result && (
        <div className="mt-4 flex items-center gap-3">
          <Image src={result.avatar} alt={`Avatar ${result.username}`} width={52} height={52} className="rounded-full object-cover" />
          <div className="min-w-0">
            <p className="truncate font-semibold">@{result.username.replace(/^@/, '')}</p>
            <a href={result.profileUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-[#4ADE80] hover:underline">Buka Profil TikTok</a>
          </div>
        </div>
      )}
    </section>
  );
}