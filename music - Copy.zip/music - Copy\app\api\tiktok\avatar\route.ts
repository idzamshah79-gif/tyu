import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

type Profile = { username: string; profileUrl: string; avatar: string; name?: string; updatedAt: string };
type Manifest = { profiles: Profile[] };
type Metadata = {
  data?: {
    user?: {
      uniqueId?: unknown;
      avatarLarger?: unknown;
      avatarMedium?: unknown;
    };
  };
};

const hosts = new Set(['tiktok.com', 'www.tiktok.com', 'm.tiktok.com']);
const usernamePattern = /^[A-Za-z0-9._-]{2,24}$/;
const directory = path.join(process.cwd(), 'public', 'AvatarTiktok');
const manifestFile = path.join(directory, 'manifest.json');
let writeQueue = Promise.resolve();

function parseProfile(value: string | null) {
  if (!value) return null;
  if (!value.includes('://')) {
    const username = value.trim().replace(/^@/, '');
    return usernamePattern.test(username) ? { username, profileUrl: `https://www.tiktok.com/@${username}` } : null;
  }
  try {
    const url = new URL(value);
    const username = url.pathname.match(/^\/@([A-Za-z0-9._-]{2,24})\/?$/)?.[1];
    if (url.protocol !== 'https:' || !hosts.has(url.hostname.toLowerCase()) || !username || !usernamePattern.test(username)) return null;
    return { username, profileUrl: `https://www.tiktok.com/@${username}` };
  } catch {
    return null;
  }
}

async function readManifest(): Promise<Manifest> {
  try {
    const value = JSON.parse(await readFile(manifestFile, 'utf8')) as Manifest;
    return Array.isArray(value.profiles) ? value : { profiles: [] };
  } catch {
    return { profiles: [] };
  }
}

function allowedImageUrl(value: string) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && /(^|\.)(tiktokcdn(?:-[a-z]+)?\.com|ibytedtos\.com|muscdn\.com|tiktok\.com)$/i.test(url.hostname);
  } catch {
    return false;
  }
}

async function getMetadata(username: string, signal: AbortSignal) {
  const apiKey = process.env.SOCIA_VAULT_API_KEY;
  if (!apiKey) throw new Error('SociaVault API key is not configured.');
  const response = await fetch(`https://api.sociavault.com/v1/scrape/tiktok/profile?handle=${encodeURIComponent(username)}`, {
    headers: { Accept: 'application/json', 'X-API-Key': apiKey }, signal, next: { revalidate: 300 },
  });
  if (!response.ok) throw new Error(`SociaVault returned ${response.status}.`);
  const data = await response.json() as Metadata;
  const user = data.data?.user;
  const avatarUrl = typeof user?.avatarLarger === 'string'
    ? user.avatarLarger
    : typeof user?.avatarMedium === 'string' ? user.avatarMedium : undefined;
  return { username: typeof user?.uniqueId === 'string' ? user.uniqueId : username, avatarUrl };
}

async function persist(profile: Profile) {
  const operation = async () => {
    await mkdir(directory, { recursive: true });
    const manifest = await readManifest();
    const index = manifest.profiles.findIndex((item) => item.username === profile.username);
    if (index === -1) manifest.profiles.push(profile);
    else manifest.profiles[index] = profile;
    await writeFile(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`);
  };
  const result = writeQueue.then(operation, operation);
  writeQueue = result.then(() => undefined, () => undefined);
  return result;
}

async function download(username: string, imageUrl: string, signal: AbortSignal) {
  if (!allowedImageUrl(imageUrl)) throw new Error('TikTok returned an unsupported avatar URL.');
  const response = await fetch(imageUrl, { signal });
  if (!response.ok) throw new Error('Avatar image could not be downloaded.');
  const type = response.headers.get('content-type')?.split(';')[0].toLowerCase();
  const extension = type === 'image/webp' ? 'webp' : type === 'image/png' ? 'png' : 'jpg';
  const filename = `${username}.${extension}`;
  await mkdir(directory, { recursive: true });
  await writeFile(path.join(directory, filename), Buffer.from(await response.arrayBuffer()));
  return `/AvatarTiktok/${filename}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as { url?: unknown };
    const profile = parseProfile(typeof body.url === 'string' ? body.url : null);
    if (!profile) return NextResponse.json({ success: false, error: 'URL profil TikTok tidak sah.' }, { status: 400 });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
      const metadata = await getMetadata(profile.username, controller.signal);
      if (!metadata.avatarUrl) return NextResponse.json({ success: false, error: 'Avatar TikTok tidak dijumpai.' }, { status: 404 });
      const result: Profile = { username: metadata.username, profileUrl: profile.profileUrl, avatar: await download(metadata.username, metadata.avatarUrl, controller.signal), updatedAt: new Date().toISOString() };
      await persist(result);
      return NextResponse.json({ success: true, ...result }, { headers: { 'Cache-Control': 'no-store' } });
    } finally {
      clearTimeout(timeout);
    }
  } catch (error) {
    console.error('TikTok Avatar API Error:', error);
    return NextResponse.json({ success: false, error: 'Avatar TikTok tidak dapat dimuatkan sekarang.' }, { status: 502 });
  }
}

export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const profile = parseProfile(params.get('username') || params.get('url'));
  if (!profile) return NextResponse.json({ success: false, error: 'Username atau URL TikTok tidak sah.' }, { status: 400 });
  const saved = (await readManifest()).profiles.find((item) => item.username === profile.username);
  if (!saved) return NextResponse.json({ success: false, error: 'Avatar profil belum disimpan.' }, { status: 404 });
  return NextResponse.json({ success: true, ...saved }, { headers: { 'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=600' } });
}
