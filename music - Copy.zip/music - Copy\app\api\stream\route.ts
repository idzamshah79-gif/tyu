import { NextRequest, NextResponse } from 'next/server';
import { createReadStream, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { Readable } from 'node:stream';

export const runtime = 'nodejs';

const privateDirectory = path.join(process.cwd(), 'private_uploads');

function resolvePrivateFile(filename: string) {
  const safeName = path.basename(filename);
  if (!safeName || safeName !== filename) return null;
  const filePath = path.join(privateDirectory, safeName);
  if (!filePath.startsWith(privateDirectory) || !existsSync(filePath)) return null;
  return filePath;
}

function mediaType(filename: string) {
  const extension = path.extname(filename).toLowerCase();
  if (extension === '.mp4') return 'video/mp4';
  if (extension === '.mp3') return 'audio/mpeg';
  if (extension === '.m4a') return 'audio/mp4';
  if (extension === '.webm') return 'video/webm';
  return 'application/octet-stream';
}

export async function GET(request: NextRequest) {
  const filename = request.nextUrl.searchParams.get('file') || 'video-13s.mp4';
  const filePath = resolvePrivateFile(filename);
  if (!filePath) return new NextResponse('Fail tidak dijumpai', { status: 404 });

  const stats = statSync(filePath);
  const fileSize = stats.size;
  const range = request.headers.get('range');
  const contentType = mediaType(filename);

  if (range) {
    const [rawStart, rawEnd] = range.replace('bytes=', '').split('-');
    const start = Number.parseInt(rawStart, 10);
    const end = rawEnd ? Number.parseInt(rawEnd, 10) : fileSize - 1;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end >= fileSize || start > end) {
      return new NextResponse('Range tidak sah', { status: 416, headers: { 'Content-Range': `bytes */${fileSize}` } });
    }

    const chunkSize = end - start + 1;
    const stream = createReadStream(filePath, { start, end });
    return new NextResponse(Readable.toWeb(stream) as ReadableStream, {
      status: 206,
      headers: {
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'no-store',
        'Content-Length': chunkSize.toString(),
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Content-Type': contentType,
      },
    });
  }

  const stream = createReadStream(filePath);
  return new NextResponse(Readable.toWeb(stream) as ReadableStream, {
    headers: {
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-store',
      'Content-Length': fileSize.toString(),
      'Content-Type': contentType,
    },
  });
}
