import { NextRequest, NextResponse } from 'next/server';
import { createReadStream, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { Readable } from 'node:stream';

export const runtime = 'nodejs';

const privateDirectory = path.join(process.cwd(), 'private_uploads');

function resolvePrivateFile(filename: string) {
  const safeName = path.basename(filename);
  if (!safeName || safeName !== filename) return null;
  const filePath = path.join(privateDirectory, safeName);
  if (!filePath.startsWith(privateDirectory) || !existsSync(filePath)) return null;
  return filePath;
}

function mediaType(filename: string) {
  const extension = path.extname(filename).toLowerCase();
  if (['.jpg', '.jpeg'].includes(extension)) return 'image/jpeg';
  if (extension === '.png') return 'image/png';
  if (extension === '.webp') return 'image/webp';
  if (extension === '.mp4') return 'video/mp4';
  if (extension === '.mp3') return 'audio/mpeg';
  return 'application/octet-stream';
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ filename: string }> }) {
  const { filename } = await params;
  const filePath = resolvePrivateFile(filename);
  if (!filePath) return new NextResponse('Fail tidak dijumpai', { status: 404 });

  const stats = statSync(filePath);
  const stream = createReadStream(filePath);
  return new NextResponse(Readable.toWeb(stream) as ReadableStream, {
    headers: {
      'Cache-Control': 'private, no-store',
      'Content-Length': stats.size.toString(),
      'Content-Type': mediaType(filename),
    },
  });
}
