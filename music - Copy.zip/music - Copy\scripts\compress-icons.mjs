import https from 'https';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import imagemin from 'imagemin';
import imageminPngquant from 'imagemin-pngquant';
import imageminWebp from 'imagemin-webp';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.join(__dirname, '../public/icons');

const icons = {
  tiktok: 'https://www.image2url.com/r2/default/images/1787472433532-fe8560d2-60d0-4f83-88d6-4e38fff2741f.png',
  instagram: 'https://www.image2url.com/r2/default/images/1787422003930-492bbcbf-700f-45c4-9807-ad440f74c6f2.png',
  whatsapp: 'https://www.image2url.com/r2/default/images/1787421864517-e0c15b68-53a1-4ef4-9d5a-efe3f43042af.png',
};

const downloadFile = (url, dest) => {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    https.get(url, (response) => {
      response.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(dest, () => {});
      reject(err);
    });
  });
};

const compress = async () => {
  try {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
      console.log(`✓ Created directory: ${outputDir}`);
    }

    const tempDir = path.join(__dirname, '../.temp-icons');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    console.log('📥 Downloading icons...');
    for (const [name, url] of Object.entries(icons)) {
      const tempPath = path.join(tempDir, `${name}.png`);
      console.log(`  Downloading ${name}...`);
      await downloadFile(url, tempPath);
      const stats = fs.statSync(tempPath);
      console.log(`  ✓ ${name}: ${(stats.size / 1024).toFixed(2)} KB`);
    }

    console.log('\n🗜️  Compressing images...');
    await imagemin([path.join(tempDir, '*.png')], {
      destination: outputDir,
      plugins: [
        imageminPngquant({
          quality: [0.6, 0.8],
          speed: 4,
        }),
      ],
    });

    console.log('  ✓ PNG compressed');

    console.log('\n📊 Final sizes:');
    fs.readdirSync(outputDir).forEach((file) => {
      const stats = fs.statSync(path.join(outputDir, file));
      console.log(`  ${file}: ${(stats.size / 1024).toFixed(2)} KB`);
    });

    // Cleanup temp directory
    fs.rmSync(tempDir, { recursive: true, force: true });
    console.log('\n✅ Compression complete! Use /icons/[name].png in your code.');
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
};

compress();
