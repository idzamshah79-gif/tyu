import { NextResponse } from 'next/server';

const AUDIO_API = 'https://api-faa.my.id/faa/ytmp3?url=';
const audioUrlCache = new Map<string, { url: string; expiresAt: number }>();

function safeFileName(value: string) {
  return value.replace(/[<>:"/\\|?*\u0000-\u001F]/g, '').replace(/\s+/g, ' ').trim().slice(0, 120) || 'lagu';
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const videoId = searchParams.get('id');
  const title = searchParams.get('title') || 'lagu';

  if (!videoId || !/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
    return NextResponse.json({ error: 'Invalid video ID' }, { status: 400 });
  }

  try {
    const sourceUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const cached = audioUrlCache.get(videoId);
    let audioUrl = cached && cached.expiresAt > Date.now() ? cached.url : null;

    if (!audioUrl) {
      const apiResponse = await fetch(`${AUDIO_API}${encodeURIComponent(sourceUrl)}`, {
        headers: { Accept: 'application/json' },
        cache: 'no-store',
      });

      if (!apiResponse.ok) {
        return NextResponse.json({ error: 'Audio API tidak tersedia.' }, { status: 502 });
      }

      const data = await apiResponse.json();
      audioUrl = data?.result?.mp3;
      if (data?.status !== true || typeof audioUrl !== 'string') {
        return NextResponse.json({ error: 'Link MP3 tidak ditemukan.' }, { status: 404 });
      }
      audioUrlCache.set(videoId, { url: audioUrl, expiresAt: Date.now() + 10 * 60 * 1000 });
    }

    const audioResponse = await fetch(audioUrl, { cache: 'no-store' });
    if (!audioResponse.ok || !audioResponse.body) {
      return NextResponse.json({ error: 'File MP3 gagal diambil.' }, { status: 502 });
    }

    const headers = new Headers();
    headers.set('Content-Type', audioResponse.headers.get('content-type') || 'audio/mpeg');
    headers.set('Content-Disposition', `attachment; filename="${safeFileName(title)}.mp3"`);
    const contentLength = audioResponse.headers.get('content-length');
    if (contentLength) headers.set('Content-Length', contentLength);

    return new NextResponse(audioResponse.body, { headers });
  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Download gagal diproses.' }, { status: 500 });
  }
}