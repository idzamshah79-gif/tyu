export { GET } from '../tiktok/avatar/route';
