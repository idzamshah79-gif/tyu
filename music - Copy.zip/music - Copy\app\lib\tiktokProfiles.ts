import profiles from './tiktokProfiles.json';

export type TikTokProfile = {
  id: number;
  name: string;
  username: string;
  url: string;
  avatar?: string;
  isVerified?: boolean;
};

export const tiktokProfiles = profiles as TikTokProfile[];