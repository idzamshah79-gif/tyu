'use client';

import Image from 'next/image';
import { CheckCircle2, LoaderCircle } from 'lucide-react';
import { useEffect, useState } from 'react';

type TikTokAvatarData = {
  username: string;
  avatar: string;
  profileUrl: string;
};

type TikTokAvatarProps = {
  profileUrl: string;
  name?: string;
  isVerified?: boolean;
  localAvatar?: string;
  className?: string;
  fullUsername?: boolean;
};

export function TikTokAvatar({ profileUrl, name, isVerified = false, localAvatar, className = '', fullUsername = false }: TikTokAvatarProps) {
  const profileUsername = profileUrl.match(/tiktok\.com\/@([^/?]+)/i)?.[1] || '';
  const [data, setData] = useState<TikTokAvatarData | null>(localAvatar ? { username: profileUsername, avatar: localAvatar, profileUrl } : null);
  const [error, setError] = useState<string | null>(null);
  const [loadedProfileUrl, setLoadedProfileUrl] = useState<string | null>(null);
  const isLoading = loadedProfileUrl !== profileUrl;

  useEffect(() => {
    const controller = new AbortController();

    fetch(`/api/tiktok/avatar?url=${encodeURIComponent(profileUrl)}`, { signal: controller.signal })
      .then(async (response) => {
        if (response.ok) return response;
        return fetch('/api/tiktok/avatar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: profileUrl }),
          signal: controller.signal,
        });
      })
      .then(async (response) => {
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Avatar TikTok tidak tersedia.');
        return result as TikTokAvatarData;
      })
      .then(setData)
      .catch((fetchError: unknown) => {
        if (fetchError instanceof DOMException && fetchError.name === 'AbortError') return;
        setError(fetchError instanceof Error ? fetchError.message : 'Avatar TikTok tidak tersedia.');
      })
      .finally(() => setLoadedProfileUrl(profileUrl));

    return () => controller.abort();
  }, [profileUrl]);

  const label = data?.username || profileUrl.match(/tiktok\.com\/@([^/?]+)/i)?.[1] || name || 'TikTok';

  return (
    <a
      href={profileUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Buka profil TikTok ${label}`}
      className={`flex w-full min-w-[140px] items-center gap-3 rounded-xl p-2 text-left transition-colors hover:bg-white/10 ${className}`}
      title={error || undefined}
    >
      <div className="shrink-0 rounded-full bg-[linear-gradient(135deg,#25F4EE,#FE2C55,#FACC15)] p-[2px]">
        <div className="relative h-[38px] w-[38px] overflow-hidden rounded-full bg-white/10">
          {data?.avatar ? (
            <Image src={data.avatar} alt={`${label} avatar`} fill sizes="38px" className="object-cover" />
          ) : isLoading ? (
            <LoaderCircle className="m-2 h-[22px] w-[22px] animate-spin text-white/70" />
          ) : (
            <span className="flex h-full items-center justify-center text-sm font-semibold text-white/70">{label.replace('@', '').charAt(0).toUpperCase()}</span>
          )}
        </div>
      </div>
      <div className="min-w-0 flex-1 pl-1">
        <span className="flex min-w-0 items-center gap-1 text-xs font-semibold text-white">
          <span className={fullUsername ? 'break-words' : 'truncate'}>{name || label}</span>
          {isVerified && <CheckCircle2 className="h-3.5 w-3.5 shrink-0 fill-blue-500 text-blue-400" />}
        </span>
        <span className={`${fullUsername ? 'break-all' : 'truncate'} block text-[11px] ${error ? 'text-red-300/80' : 'text-white/50'}`}>
          {error ? 'Avatar tidak tersedia' : `@${(data?.username || profileUsername || label).replace(/^@/, '')}`}
        </span>
      </div>
    </a>
  );
}

export default TikTokAvatar;
