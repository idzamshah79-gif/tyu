import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const avatarDirectory = path.join(root, 'public', 'AvatarTiktok');
const manifestPath = path.join(avatarDirectory, 'manifest.json');
const profiles = JSON.parse(await readFile(path.join(root, 'app', 'lib', 'tiktokProfiles.json'), 'utf8'));

await mkdir(avatarDirectory, { recursive: true });
let manifest = { profiles: [] };
try {
  manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
} catch {
  manifest = { profiles: [] };
}
if (!Array.isArray(manifest.profiles)) manifest = { profiles: [] };

for (const profile of profiles) {
  const profileUrl = new URL(profile.url);
  profileUrl.search = '';
  const canonicalUrl = profileUrl.toString().replace(/\/$/, '');
  const username = canonicalUrl.match(/\/@([^/]+)$/)?.[1];
  if (!username || manifest.profiles.some((item) => item.username === username)) continue;

  try {
    const metadataResponse = await fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(canonicalUrl)}`, {
      headers: { Accept: 'application/json' },
    });
    let avatarUrl;
    if (metadataResponse.ok) {
      const metadata = await metadataResponse.json();
      avatarUrl = typeof metadata.thumbnail_url === 'string' ? metadata.thumbnail_url : undefined;
    }
    if (!avatarUrl) {
      const pageResponse = await fetch(canonicalUrl, { headers: { Accept: 'text/html' } });
      if (!pageResponse.ok) throw new Error(`profile returned ${pageResponse.status}`);
      const html = await pageResponse.text();
      const image = html.match(/<meta[^>]+(?:property|name)=["'](?:og:image|twitter:image)["'][^>]+content=["']([^"']+)["']/i)
        || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["'](?:og:image|twitter:image)["']/i);
      avatarUrl = image?.[1];
    }
    if (!avatarUrl) throw new Error('no avatar was returned');

    const imageResponse = await fetch(avatarUrl);
    if (!imageResponse.ok) throw new Error(`avatar download returned ${imageResponse.status}`);
    const type = imageResponse.headers.get('content-type')?.split(';')[0].toLowerCase();
    const extension = type === 'image/png' ? 'png' : type === 'image/webp' ? 'webp' : 'jpg';
    const filename = `${username}.${extension}`;
    await writeFile(path.join(avatarDirectory, filename), Buffer.from(await imageResponse.arrayBuffer()));
    const profile = {
      username,
      profileUrl: canonicalUrl,
      avatar: `/AvatarTiktok/${filename}`,
      updatedAt: new Date().toISOString(),
    };
    manifest.profiles.push(profile);
    console.log(`Downloaded ${canonicalUrl} -> ${profile.avatar}`);
  } catch (error) {
    console.warn(`Skipped ${canonicalUrl}: ${error instanceof Error ? error.message : 'unknown error'}`);
  }
}

await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);