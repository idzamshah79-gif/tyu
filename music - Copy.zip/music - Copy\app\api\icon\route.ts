import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const res = await fetch('https://www.image2url.com/r2/default/images/1787417493484-d189a842-9f1b-456f-8c38-e8fbf0f8b507.jpg');
    const buffer = await res.arrayBuffer();
    
    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'image/jpeg',
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
    });
  } catch (error) {
    console.error('Error fetching icon:', error);
    return new NextResponse('Error fetching icon', { status: 500 });
  }
}
