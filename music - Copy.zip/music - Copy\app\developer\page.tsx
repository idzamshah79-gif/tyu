'use client';

import Image from 'next/image';
import { ArrowLeft, Download, CheckCircle2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { motion } from 'motion/react';
import { usePWAInstall } from '@/hooks/usePWAInstall';
import TikTokAvatar from '@/app/EngineIconTiktok';
import { tiktokProfiles } from '@/app/lib/tiktokProfiles';

const channelIcons = {
  website: 'https://www.image2url.com/r2/default/images/1787419610001-703c02e2-b32b-4f2f-8727-5192aa1f2f5e.png',
  whatsapp: 'https://www.image2url.com/r2/default/images/1787421864517-e0c15b68-53a1-4ef4-9d5a-efe3f43042af.png',
  tiktok: 'https://www.image2url.com/r2/default/images/1787472433532-fe8560d2-60d0-4f83-88d6-4e38fff2741f.png',
  instagram: 'https://www.image2url.com/r2/default/images/1787422003930-492bbcbf-700f-45c4-9807-ad440f74c6f2.png',
  touchNGo: 'https://www.image2url.com/r2/default/images/1787474714590-ffa28636-564f-4fce-a9f2-078684a8ba3c.webp',
};

export default function DeveloperPage() {
  const router = useRouter();
  const { installPWA } = usePWAInstall();
  const [isTikTokOpen, setIsTikTokOpen] = useState(false);
  return (
    <main className="relative min-h-screen overflow-hidden pb-24">
      <div className="pointer-events-none absolute left-1/2 top-20 -z-10 h-72 w-72 -translate-x-1/2 rounded-full bg-[#4ADE80]/10 blur-3xl" />
      <div className="sticky top-0 z-40 flex items-center gap-4 border-b border-white/10 bg-black/25 px-4 pb-4 pt-6 backdrop-blur-xl">
        <button onClick={() => router.back()} className="text-white hover:bg-white/10 p-2 rounded-full transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-medium text-white">INFO</h1>
      </div>

      <div className="px-6 pt-6">
        <h2 className="mb-8 text-center text-[#4ADE80] text-sm font-medium">Share to</h2>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center text-center space-y-6"
        >
          {/* Glass liquid profile ball */}
          <div className="relative isolate h-48 w-48 shrink-0 overflow-hidden rounded-full border border-white/50 bg-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.35),inset_0_0_24px_rgba(255,255,255,0.3)] backdrop-blur-md mb-2">
            <div className="absolute -inset-8 rounded-[45%] bg-[#4ADE80]/30 blur-2xl animate-[liquid_7s_ease-in-out_infinite]" />
            <div className="absolute -bottom-16 -left-6 h-36 w-64 rounded-[50%] bg-[#38BDF8]/35 blur-md animate-[liquid_9s_ease-in-out_infinite_reverse]" />
            <div className="absolute inset-3 rounded-full border border-white/30 bg-white/5" />
            <div className="absolute left-8 top-6 h-12 w-24 -rotate-12 rounded-full bg-white/35 blur-xl" />
            <div className="relative z-10 h-full w-full overflow-hidden rounded-full">
              <Image
                src="https://www.image2url.com/r2/default/images/1787417493484-d189a842-9f1b-456f-8c38-e8fbf0f8b507.jpg"
                alt="ELFIE"
                fill
                sizes="192px"
                priority
                className="object-cover opacity-90 mix-blend-luminosity"
              />
            </div>
            <div className="pointer-events-none absolute inset-0 z-20 rounded-full bg-[linear-gradient(145deg,rgba(255,255,255,0.35),transparent_35%,rgba(56,189,248,0.12)_70%,rgba(255,255,255,0.2))]" />
          </div>

          <div className="flex items-center justify-center gap-2 mb-2">
            <h2 className="text-2xl font-bold text-white">3 harvard</h2>
            <CheckCircle2 className="w-6 h-6 text-blue-500 fill-blue-500/20" />
          </div>

          <p className="text-white/60 text-sm leading-relaxed max-w-sm mb-6">
            platform yang direka khas untuk kelas 3harvard. Memudahkan pelajar menikmati music tanpa had sekaligus menggantikan platform music berbayar  .
          </p>

          <div className="relative w-full max-w-sm">
            <div className="no-scrollbar flex w-full snap-x gap-2 overflow-x-auto rounded-3xl border border-white/10 bg-white/[0.06] p-2 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_12px_30px_rgba(0,0,0,0.2)] backdrop-blur-xl">
              <a href="https://elfie-3harvard.vercel.app" target="_blank" rel="noopener noreferrer" className="flex min-w-[78px] snap-start flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.08] px-2 py-3 transition-colors hover:bg-white/[0.16]">
                <Image src={channelIcons.website} alt="Website" width={24} height={24} />
                <span className="text-[11px] text-white/70 font-medium">Website</span>
              </a>
              <a href="https://whatsapp.com/channel/0029VbCbQeRKgsNudJy1Vd3p" target="_blank" rel="noopener noreferrer" className="flex min-w-[78px] snap-start flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.08] px-2 py-3 transition-colors hover:bg-white/[0.16]">
                <Image src={channelIcons.whatsapp} alt="WhatsApp" width={24} height={24} />
                <span className="text-[11px] text-white/70 font-medium">Saluran</span>
              </a>
              <div className="min-w-[78px]">
                <button type="button" onClick={() => setIsTikTokOpen((open) => !open)} aria-expanded={isTikTokOpen} aria-haspopup="dialog" className="flex w-full snap-start flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.08] px-2 py-3 transition-colors hover:bg-white/[0.16]">
                  <Image src={channelIcons.tiktok} alt="TikTok" width={24} height={24} />
                  <span className="text-[11px] text-white/70 font-medium">TikTok</span>
                </button>
              </div>
              <a href="https://www.instagram.com/cherylsoftspoken/" target="_blank" rel="noopener noreferrer" className="flex min-w-[78px] snap-start flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.08] px-2 py-3 transition-colors hover:bg-white/[0.16]">
                <Image src={channelIcons.instagram} alt="Instagram" width={24} height={24} />
                <span className="text-[11px] text-white/70 font-medium">Instagram</span>
              </a>
            </div>
            {isTikTokOpen && (
              <motion.div initial={{ opacity: 0, y: -8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} role="dialog" aria-label="TikTok profiles" className="absolute left-1/2 top-[calc(100%+12px)] z-50 w-[min(440px,calc(100vw-32px))] -translate-x-1/2 rounded-2xl border border-white/10 bg-[#171719]/95 p-4 text-left shadow-2xl backdrop-blur-xl">
                <div className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 border-l border-t border-white/10 bg-[#171719]" />
                <div className="mb-3">
                  <span className="text-sm font-semibold text-white">TikTok profiles</span>
                </div>
                <div className="no-scrollbar flex snap-x gap-2 overflow-x-auto pb-1">
                  {tiktokProfiles.map((profile) => (
                    <TikTokAvatar
                      key={profile.id}
                      profileUrl={profile.url}
                      name={profile.name}
                      isVerified={profile.isVerified}
                      localAvatar={profile.avatar}
                      fullUsername
                      className="min-w-[168px] snap-start"
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          <a
            href="https://www.image2url.com/r2/default/images/1787474231369-055648ec-d3d4-4f1c-a060-5004f11d9727.jpg"
            target="_blank"
            rel="noopener noreferrer"
            className="mb-8 flex w-full max-w-sm items-center gap-4 rounded-3xl border border-white/10 bg-white/[0.08] p-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_12px_30px_rgba(0,0,0,0.2)] backdrop-blur-xl transition-colors hover:bg-white/[0.14]"
          >
            <div className="w-12 h-12 rounded-full bg-[#224032] flex items-center justify-center shrink-0">
              <Image src={channelIcons.touchNGo} alt="Touch 'n Go" width={32} height={32} />
            </div>
            <div className="text-left">
              <div className="text-white font-medium">Donate </div>
              <div className="text-white/50 text-sm">Support elfie</div>
            </div>
          </a>

          <button
            onClick={installPWA}
            className="w-full max-w-sm flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/[0.08] px-6 py-4 font-medium text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_12px_30px_rgba(0,0,0,0.2)] backdrop-blur-xl transition-colors hover:bg-white/[0.14]"
          >
            <Download className="w-5 h-5" />
            <span>Download APK</span>
          </button>
        </motion.div>
      </div>

      <style jsx global>{`
        @keyframes liquid {
          0%, 100% { transform: translate3d(-3%, 2%, 0) rotate(-8deg) scale(1); }
          50% { transform: translate3d(8%, -8%, 0) rotate(12deg) scale(1.08); }
        }
      `}</style>
    </main>
  );
}
