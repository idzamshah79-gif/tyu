import type {Metadata, Viewport} from 'next';
import './globals.css'; // Global styles
import { BottomNav } from '@/components/BottomNav';
import { Player } from '@/components/Player';
import { AddToPlaylistModal } from '@/components/AddToPlaylistModal';
import { PWARegister } from '@/components/PWARegister';
import { BackgroundProvider } from '@/components/BackgroundProvider';

export const metadata: Metadata = {
  metadataBase: new URL('https://elfie-3harvard.com'),
  title: {
    default: 'Music App 3 Harvard | Platform Muzik Percuma Elfie',
    template: '%s | Music App 3 Harvard',
  },
  keywords: [
    'elfie',
    '3harvard',
    'elfie 3harvard',
    '3harvard music',
    'music app 3 harvard',
    '3harvard music app',
    'elfie music',
    'cherylsoftspoken',
    '3 harvard',
    'platform muzik percuma',
  ],
  authors: [{name: 'Elfie'}],
  creator: 'Elfie',
  publisher: '3Harvard',
  verification: {
    google: 'RuXQyfgtXezVpJxXmkZfDMSSG_GBSrnWxWtF-be-Mrk',
  },
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    title: 'Music App 3 Harvard | Platform Muzik Percuma',
    description: 'Platform muzik khas direka untuk kelas 3Harvard oleh Elfie. Memudahkan pelajar menikmati muzik tanpa had.',
    url: 'https://elfie-3harvard.com',
    siteName: 'Music App 3 Harvard',
    locale: 'ms_MY',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Music App 3 Harvard',
    description: 'Platform muzik percuma tanpa had khas untuk pelajar kelas 3Harvard.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'Music App 3Harvard',
  },
  icons: {
    icon: [
      { url: '/favicon.ico', sizes: '48x48', type: 'image/x-icon' },
      { url: '/favicon-48.png', sizes: '48x48', type: 'image/png' },
      { url: '/favicon-192.png', sizes: '192x192', type: 'image/png' },
    ],
    shortcut: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
};



export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body className="text-white antialiased pb-24 min-h-screen" suppressHydrationWarning>
        <BackgroundProvider />
        <PWARegister />
        {children}
        <Player />
        <BottomNav />
        <AddToPlaylistModal />
      </body>
    </html>
  );
}

  
